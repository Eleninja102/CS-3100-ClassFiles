//Coleton Watt
//Example xv6 program

//standard includes
#include "kernel/types.h"
#include "user/user.h"


int main(int argc, char *argv[]) {
	printf("Hello World!!\n");
	
	
	
	exit(0);
	
}
